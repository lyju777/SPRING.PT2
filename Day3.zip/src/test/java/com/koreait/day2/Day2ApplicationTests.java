package com.koreait.day2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class Day2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
