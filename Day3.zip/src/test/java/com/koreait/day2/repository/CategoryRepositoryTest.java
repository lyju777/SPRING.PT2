package com.koreait.day2.repository;

import com.koreait.day2.Day2ApplicationTests;
import com.koreait.day2.model.entity.Category;
import com.koreait.day2.model.entity.TbTbuser;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.util.Optional;

public class CategoryRepositoryTest extends Day2ApplicationTests {

    @Autowired
    private CategoryRepository categoryRepository;

    // 자동차, 컴퓨터, 가전
    @Test
    public void create(){
        Category category = Category.builder()
                .type("라이젠")
                .title("cpu")
                .regDate(LocalDateTime.now())
                .build();

        Category newCategory = categoryRepository.save(category);
    }


    @Test
    public void update() {
        Optional<Category> category = categoryRepository.findById(6L);
        category.ifPresent(selectCategory -> {
            selectCategory.setType("선박");
            selectCategory.setTitle("모터보드");
            categoryRepository.save(selectCategory);
        });
    }
}

