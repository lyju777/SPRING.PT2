package com.koreait.day2.repository;

import com.koreait.day2.Day2ApplicationTests;
import com.koreait.day2.model.entity.TbTbuser;
import com.koreait.day2.model.enumclass.UserStatus;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import javax.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.Optional;

public class UserRepositoryTest extends Day2ApplicationTests {

    @Autowired  // 아까 만든 repository를 가져다 쓸 수 있게 함
    private UserRepository UserRepository;

    @Test // 단위 테스트로 사용
    public void create() {
        TbTbuser user = TbTbuser.builder()
                .userid("nice")    // setter()
                .userpw("6666")
                .hp("010-6666-6666")
                .email("nice@nice.com")
                .status(UserStatus.REGISTERED)
                .regDate(LocalDateTime.now())
                .updateDate(LocalDateTime.now())
                .build();
        // builder를 이용해 메소드 체이닝 방식으로 setter를 사용해 줄 수 있음.
        TbTbuser newUser = UserRepository.save(user);
    }

    @Test
    @Transactional
    public void read() {
        // select * from users where userid=?
//        Optional<TbTbuser> user = UserRepository.findByUserid("admin");
//        user.ifPresent(selectUser -> {
//            System.out.println("users : " + selectUser);
//            System.out.println("userid : " + selectUser.getUserid());
//            System.out.println("userpw : " + selectUser.getUserpw());
//            System.out.println("email : " + selectUser.getEmail());
//        });

//        TbTbuser user = UserRepository.findFirstByemailOrderByIdDesc("apple@apple.com");
//        if(user != null) {
//            System.out.println("데이터가 존재합니다!");
//        }else{
//            System.out.println("데이터가 존재하지 않습니다");
//        }

        TbTbuser user = UserRepository.findFirstByemailOrderByIdDesc("apple@apple.com");
        if (user != null) {
            System.out.println(user.getUserid() + "님의 주문 리스트입니다.");
            System.out.println("=======================================");
            // System.out.println(user.getOrderGroupList().stream().count());
            user.getOrderGroupList().stream().forEach(orderGroup -> {
                System.out.println("****** 주문내역 ******");
                System.out.println("수령인 : " + orderGroup.getRevName());
                System.out.println("수령지 : " + orderGroup.getRevAddress());
                System.out.println("수량 : " + orderGroup.getTotalQuantity());
                System.out.println("금액 : " + orderGroup.getTotalPrice());
                System.out.println("****** 주문상세 ******");
                orderGroup.getOrderDetailList().forEach(orderDetail -> {
                    System.out.println("주문의 상태 :" + orderDetail.getStatus());
                    System.out.println("도착예정일자 :" + orderDetail.getArrivalDate());
                    System.out.println("상품명 :" + orderDetail.getItem().getName());

                    System.out.println("파트너명 : " + orderDetail.getItem().getPartner().getName());
                    System.out.println("고객센터 전화번호 : " + orderDetail.getItem().getPartner().getCallCenter());
                    System.out.println("상품카테고리 : " + orderDetail.getItem().getPartner().getCategory().getTitle());
                });

            });

        } else {
            System.out.println("데이터가 존재하지 않습니다");
        }
    }

    @Test
    public void update() {
        Optional<TbTbuser> user = UserRepository.findByUserid("admin");
        user.ifPresent(selectUser -> {
            selectUser.setEmail("banana@banana.com");
            selectUser.setUpdateDate(LocalDateTime.now());
            UserRepository.save(selectUser);
        });
    }

    @Test
    public void delete() {
        Optional<TbTbuser> user = UserRepository.findByUserid("admin");

        user.ifPresent(selectUser -> {
            UserRepository.delete(selectUser);
        });

        Optional<TbTbuser> deleteuser = UserRepository.findByUserid("admin");
        if (deleteuser.isPresent()) {
            System.out.println("삭제실패!");
        } else {
            System.out.println("삭제성공!");
        }
    }
}