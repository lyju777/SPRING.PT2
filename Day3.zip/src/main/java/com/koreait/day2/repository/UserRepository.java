package com.koreait.day2.repository;


import com.koreait.day2.model.entity.TbTbuser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<TbTbuser, Long> {
    // select * from TbTbuser where userid=?
    Optional<TbTbuser> findByUserid(String userid);

    // select * from TbTbuser where userid=? and userpw=?
    Optional<TbTbuser> findByUseridAndUserpw(String userid, String userpw);

    // select * from TbTbuser where rownum <= 1 order by id desc
    TbTbuser findFirstByemailOrderByIdDesc(String email);


}
