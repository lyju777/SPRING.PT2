package com.koreait.day2.model.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;

@Data //  자동으로 getter/Setter를 지원
@AllArgsConstructor // 모든 매개변수를 지원하는 생성자를 생성
@NoArgsConstructor // 매개변수가 없는 생성자를 생성
@Entity // AdminUser JPA기능을 사용해서 DB 테이블과 연결 JAP에서 테이블을 자동으로 관리해주는 기능을 가진 객체를 생성하는 어노테이션
@SequenceGenerator(
        name="seq_user", // 내 마음대로 이름 작성해도 됨
        sequenceName = "seq_user", // 오라클의 sequenceName 과 동일하게 작성
        initialValue = 1,  // 초기 value값 설정
        allocationSize = 1 // size 설정
)
@Builder // 메소드 체이닝을 사용하게 만들어줌
@EntityListeners(AuditingEntityListener.class)
public class AdminUser {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_user") //  name="seq_user" 과 동일한 이름
    private Long id;        // 일렬번호
    private String userid;  // 아이디
    private String userpw;  // 비밀번호
    private String name;    // 이름
    private String status;  // 상태
    private LocalDateTime lastLoginAt;   // 마지막 접속시간
    @CreatedDate
    private LocalDateTime regDate;       // 가입 날짜

    @CreatedBy
    private String createBy;
}
