package com.koreait.day2.model.entity;

import com.koreait.day2.model.enumclass.UserStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.scheduling.support.SimpleTriggerContext;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity // AdminUser JPA기능을 사용해서 DB 테이블과 연결
@SequenceGenerator(
        name="seq_tbuser", // 내 마음대로 이름 작성해도 됨
        sequenceName = "seq_tbuser", // 오라클의 sequenceName 과 동일하게 작성
        initialValue = 1,  // 초기 value값 설정
        allocationSize = 1 // size 설정
)
@Builder // 메소드 체이닝을 사용하게 만들어줌
@EntityListeners(AuditingEntityListener.class)
public class TbTbuser {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_tbuser") //  name="seq_user" 과 동일한 이름
    private Long id;
    private String userid;
    private String userpw;
    private String hp;
    private String email;
    @CreatedDate
    private LocalDateTime regDate;
    @LastModifiedDate
    private LocalDateTime updateDate;

    @Enumerated(EnumType.STRING)
    private UserStatus status;  // REGISTERED, UNREGISTERED

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "tbTbuser")   // "tbtbuser" = 테이블명
    private List<OrderGroup> orderGroupList;
}