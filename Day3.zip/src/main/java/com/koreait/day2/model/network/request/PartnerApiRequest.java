package com.koreait.day2.model.network.request;




public class PartnerApiRequest {
}
