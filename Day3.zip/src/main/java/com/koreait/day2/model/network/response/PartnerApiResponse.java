package com.koreait.day2.model.network.response;

public class PartnerApiResponse {
}
