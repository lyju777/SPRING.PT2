package com.koreait.day2.service;

import com.koreait.day2.ifs.CrudInterface;
import com.koreait.day2.model.entity.TbTbuser;
import com.koreait.day2.model.enumclass.UserStatus;
import com.koreait.day2.model.network.Header;
import com.koreait.day2.model.network.request.UserApiRequest;
import com.koreait.day2.model.network.response.UserApiResponse;
import com.koreait.day2.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service  // 서비스레이어, 내부에서 자바로직을 처리함
@RequiredArgsConstructor
public class UserApiLogicService implements CrudInterface<UserApiRequest, UserApiResponse> {


    private final UserRepository userRepository;

    @Override
    public Header<UserApiResponse> create(Header<UserApiRequest> request) {

        UserApiRequest userApiRequest = request.getData();

        TbTbuser user = TbTbuser.builder()
                .userid(userApiRequest.getUserid())
                .userpw(userApiRequest.getUserpw())
                .hp(userApiRequest.getHp())
                .email(userApiRequest.getEmail())
                .status(UserStatus.REGISTERED)
                .build();
        TbTbuser newUser = userRepository.save(user);
        return response(newUser);

    }

    @Override
    public Header<UserApiResponse> read(Long id) {
        return userRepository.findById(id)
                .map(user -> response(user))
                .orElseGet(
                        () -> Header.ERROR("데이터 없음")
                );
    }

    @Override
    public Header<UserApiResponse> update(Header<UserApiRequest> request) {

        UserApiRequest userApiRequest = request.getData();
        Optional<TbTbuser> optional = userRepository.findById(userApiRequest.getId());

        return optional.map(user ->{
            user.setUserid(userApiRequest.getUserid());
            user.setUserpw(userApiRequest.getUserid());
            user.setHp(userApiRequest.getHp());
            user.setEmail(userApiRequest.getEmail());
            user.setStatus(userApiRequest.getStatus());
            return user;
        }).map(user -> userRepository.save(user))
                .map(user -> response(user))
                .orElseGet(() -> Header.ERROR("데이터 없음"));
    }

    @Override
    public Header delete(Long id) {
        Optional<TbTbuser> optional = userRepository.findById(id);

        return optional.map(user -> {
            userRepository.delete(user);
            return Header.OK();
        }).orElseGet(() -> Header.ERROR("데이터 없음"));
    }


    private Header<UserApiResponse> response(TbTbuser user){
        UserApiResponse userApiResponse = UserApiResponse.builder()
                .id(user.getId())
                .userid(user.getUserid())
                .userpw(user.getUserpw())
                .email(user.getEmail())
                .hp(user.getHp())
                .regDate(user.getRegDate())
                .status((user.getStatus()))
                .build();
        return Header.OK(userApiResponse);
    }
}
