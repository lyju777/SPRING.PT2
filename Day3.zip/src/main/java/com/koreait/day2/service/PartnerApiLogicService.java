package com.koreait.day2.service;

public class PartnerApiLogicService {
}
