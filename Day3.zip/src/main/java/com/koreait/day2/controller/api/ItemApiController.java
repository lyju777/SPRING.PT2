package com.koreait.day2.controller.api;


import com.koreait.day2.ifs.CrudInterface;
import com.koreait.day2.model.network.Header;
import com.koreait.day2.model.network.request.ItemApiRequest;
import com.koreait.day2.model.network.response.ItemApiResponse;
import com.koreait.day2.service.ItemApiLogicService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/item")
@RequiredArgsConstructor
public class ItemApiController implements CrudInterface<ItemApiRequest, ItemApiResponse> {

    private final ItemApiLogicService itemApiLogicService;


    @Override
    @PostMapping("")   // http://127.0.0.1:9090/api/item
    public Header<ItemApiResponse> create(@RequestBody Header<ItemApiRequest> request) {
        System.out.println(request);
        return itemApiLogicService.create(request);
    }

    @Override
    @GetMapping("{id}") // /api/item/{id} (get)  // http://127.0.0.1:9090/api/item/1
    public Header<ItemApiResponse> read(@PathVariable(name="id") Long id) {
        return itemApiLogicService.read(id);
    }


    @Override
    @PutMapping("") // /api/item (put)  // http://127.0.0.1:9090/api/item
    public Header<ItemApiResponse> update(@RequestBody Header<ItemApiRequest> request) {
        return itemApiLogicService.update(request);
    }


    @Override
    @DeleteMapping("{id}") // /api/item/{id}
    public Header<ItemApiResponse> delete(@PathVariable(name="id")Long id) {
        return itemApiLogicService.delete(id);
    }
}

