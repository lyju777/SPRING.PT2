package com.koreait.day2.controller.api;

import com.koreait.day2.ifs.CrudInterface;
import com.koreait.day2.model.network.Header;
import com.koreait.day2.model.network.request.UserApiRequest;
import com.koreait.day2.model.network.response.UserApiResponse;
import com.koreait.day2.service.UserApiLogicService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/user")
@RequiredArgsConstructor
public class UserApiController implements CrudInterface<UserApiRequest, UserApiResponse> {

    private final UserApiLogicService userApiLogicService;

    /*
        {
            "transaction_time":"2021-08-23",
            "resultCode":"OK",
            "description":"OK",
            "data":{
                "userid":"cherry",
                "userpw":"1234",
                "email":"cherry@cherry.com",
                "hp":"010-1234-1234"
            }
        }
     */




    @Override
    @PostMapping("")   // http://127.0.0.1:9090/api/user
    public Header<UserApiResponse> create(@RequestBody Header<UserApiRequest> request) {
        System.out.println(request);
        return userApiLogicService.create(request);
    }

        /*
        {
            "transaction_time":"2021-08-23",
            "resultCode":"OK",
            "description":"OK",
            "data":{
                "userid":"cherry",
                "userpw":"1234",
                "email":"cherry@cherry.com",
                "hp":"010-1234-1234"
            }
        }
     */


    @Override
    @GetMapping("{id}") // /api/user/{id} (get)  // http://127.0.0.1:9090/api/user/101
    public Header<UserApiResponse> read(@PathVariable(name="id") Long id) {
        return userApiLogicService.read(id);
    }


    @Override
    @PutMapping("") // /api/user (put)  // http://127.0.0.1:9090/api/user
    public Header<UserApiResponse> update(@RequestBody Header<UserApiRequest> request) {
        return userApiLogicService.update(request);
    }

    /*
    {
        "transaction_time":"2021-08-23",
            "resultCode":"OK",
            "description":"OK",
            "data":{
        "id":101,
                "userid":"cherry",
                "userpw":"9999",
                "email":"cherry@naver.com",
                "hp":"010-9999-9999"
           }
        }
    */

    @Override
    @DeleteMapping("{id}") // /api/user/{id}
    public Header<UserApiResponse> delete(@PathVariable(name="id")Long id) {
        return userApiLogicService.delete(id);
    }
}
